import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet, I18nManager, Platform } from 'react-native';
import { WebView } from 'react-native-webview';

// تفعيل RTL
try { I18nManager.allowRTL(true); I18nManager.forceRTL(true); } catch(e) {}

// --- الثوابت المصححة ---
const ADMIN_PASSWORD = "5588";
const COLORS = {
  primary: '#E53935',
  secondary: '#FFC107',
  background: '#FFF8E1',
  text: '#212121',
  white: '#FFFFFF'
};

// --- مكون الخريطة المصحح (يمنع Domain: undefined) ---
function MapView({ lat, lon }) {
  if (!lat || !lon) {
    return (
      <View style={styles.mapPlaceholder}>
        <Text style={{textAlign: 'center'}}>📍 اختر نقطة الانطلاق والوصول لعرض الخريطة</Text>
      </View>
    );
  }
  // نستخدم رابط ثابت وصحيح لـ OSM لمنع خطأ Domain: undefined
  const bbox = `${lon - 0.01},${lat - 0.01},${lon + 0.01},${lat + 0.01}`;
  const uri = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat},${lon}`;
  
  return (
    <View style={styles.mapContainer}>
      <WebView
        source={{ uri }}
        style={{ flex: 1 }}
        originWhitelist={['*']}
        javaScriptEnabled={true}
      />
    </View>
  );
}

export default function App() {
  const [role, setRole] = useState('Customer'); // Customer, Driver, Admin
  const [pickup, setPickup] = useState('');
  const [dropoff, setDropoff] = useState('');
  const [pickupCoords, setPickupCoords] = useState(null);
  const [searching, setSearching] = useState(false);
  
  // حماية الادمن - بدل prompt()
  const [showAdminAuth, setShowAdminAuth] = useState(false);
  const [adminPinInput, setAdminPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  // دالة البحث المصححة (تمنع ERR_FAILED)
  const searchPlace = async (query, type) => {
    if (!query) return;
    setSearching(true);
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&countrycodes=iq&limit=1`, {
        headers: {
          'User-Agent': 'TukTukBalyApp/1.0 (ehabiraq69@example.com)',
          'Accept-Language': 'ar'
        }
      });
      const data = await res.json();
      if (data && data[0]) {
        const { lat, lon } = data[0];
        setPickupCoords({ lat: parseFloat(lat), lon: parseFloat(lon) });
      }
    } catch (e) {
      console.log('Search Error', e);
    } finally {
      setSearching(false);
    }
  };

  const handleRoleChange = (newRole) => {
    if (newRole === 'Admin') {
      setShowAdminAuth(true);
    } else {
      setRole(newRole);
    }
  };

  const verifyAdmin = () => {
    if (adminPinInput === ADMIN_PASSWORD) {
      setRole('Admin');
      setShowAdminAuth(false);
      setAdminPinInput('');
      setPinError('');
    } else {
      setPinError('رمز الدخول خطأ! الرمز هو 5588');
    }
  };

  return (
    <View style={styles.root}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>تكتك بلي 🛺</Text>
        <Text style={styles.subtitle}>تطبيق التكتك الأول في بغداد</Text>

        {/* اختيار الدور */}
        <View style={styles.roleContainer}>
          {['Customer', 'Driver', 'Admin'].map((r) => (
            <Pressable
              key={r}
              onPress={() => handleRoleChange(r)}
              style={[styles.roleBtn, role === r && styles.roleBtnActive]}
            >
              <Text style={[styles.roleText, role === r && styles.roleTextActive]}>
                {r === 'Customer' ? 'زبون' : r === 'Driver' ? 'سائق' : 
                 
              </Text>
            </Pressable>
          ))}
        </View>

        {/* واجهة الزبون */}
        {role === 'Customer' && (
          <View style={styles.card}>
            <Text style={styles.label}>من وين؟ (الانطلاق)</Text>
            <TextInput
              style={styles.input}
              placeholder="مثلا: المنصور، بغداد"
              value={pickup}
              onChangeText={setPickup}
              onSubmitEditing={() => searchPlace(pickup, 'pickup')}
            />
            <Text style={styles.label}>لوين؟ (الوصول)</Text>
            <TextInput
              style={styles.input}
              placeholder="مثلا: الكرادة، بغداد"
              value={dropoff}
              onChangeText={setDropoff}
            />
            <Pressable style={styles.mainBtn} onPress={() => searchPlace(pickup, 'pickup')}>
              <Text style={styles.mainBtnText}>{searching ? 'جاري البحث...' : 'ابحث عن تكتك'}</Text>
            </Pressable>

            <MapView lat={pickupCoords?.lat} lon={pickupCoords?.lon} />
          </View>
        )}

        {role === 'Driver' && (
          <View style={styles.card}>
            <Text style={{textAlign:'center', fontSize:18}}>مرحبا بك كسائق في تكتك بلي</Text>
            <Text style={{textAlign:'center', marginTop:10, color:'#666'}}>الطلبات القريبة منك ستظهر هنا</Text>
          </View>
        )}

        {role === 'Admin' && (
          <View style={styles.card}>
            <Text style={{textAlign:'center', fontSize:18, fontWeight:'bold'}}>لوحة تحكم الإدارة</Text>
            <Text style={{textAlign:'center', marginTop:10}}>تم الدخول بنجاح - كلمة السر 5588</Text>
            <Pressable style={[styles.mainBtn, {backgroundColor: '#333'}]} onPress={() => setRole('Customer')}>
              <Text style={styles.mainBtnText}>تسجيل خروج</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>

      {/* مودال دخول الادمن - يصلح خطأ prompt */}
      {showAdminAuth && (
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>دخول الإدارة 🔐</Text>
            <TextInput
              style={styles.input}
              placeholder="ادخل الرمز 5588"
              value={adminPinInput}
              onChangeText={setAdminPinInput}
              secureTextEntry
              keyboardType="number-pad"
              autoFocus
            />
            {pinError ? <Text style={styles.errorText}>{pinError}</Text> : null}
            <Pressable style={styles.mainBtn} onPress={verifyAdmin}>
              <Text style={styles.mainBtnText}>دخول</Text>
            </Pressable>
            <Pressable style={styles.cancelBtn} onPress={() => setShowAdminAuth(false)}>
              <Text style={styles.cancelText}>إلغاء</Text>
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.background },
  container: { padding: 20, paddingTop: 50 },
  title: { fontSize: 32, fontWeight: 'bold', textAlign: 'center', color: COLORS.primary },
  subtitle: { fontSize: 16, textAlign: 'center', marginBottom: 20, color: '#666' },
  roleContainer: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 20 },
  roleBtn: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#ddd' },
  roleBtnActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  roleText: { color: COLORS.text },
  roleTextActive: { color: COLORS.white, fontWeight: 'bold' },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 16, elevation: 3, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 10 },
  label: { textAlign: 'right', marginTop: 10, marginBottom: 5, fontWeight: 'bold' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 12, textAlign: 'right', backgroundColor: '#fafafa' },
  mainBtn: { backgroundColor: COLORS.primary, padding: 15, borderRadius: 10, alignItems: 'center', marginTop: 15 },
  mainBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  mapContainer: { height: 300, borderRadius: 12, overflow: 'hidden', marginTop: 15, backgroundColor: '#eee' },
  mapPlaceholder: { height: 300, borderRadius: 12, backgroundColor: '#f0f0f0', justifyContent: 'center', alignItems: 'center', marginTop: 15 },
  modalOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20, zIndex: 100 },
  modal: { backgroundColor: '#fff', padding: 20, borderRadius: 16 },
  modalTitle: { textAlign: 'center', fontWeight: 'bold', fontSize: 18, marginBottom: 15 },
  errorText: { color: 'red', textAlign: 'center', marginTop: 5 },
  cancelBtn: { padding: 12, alignItems: 'center', marginTop: 5 },
  cancelText: { color: '#666' }
});
